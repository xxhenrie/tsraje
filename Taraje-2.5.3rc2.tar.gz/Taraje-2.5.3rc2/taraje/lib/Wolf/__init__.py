# -*- coding: utf-8 -*-
"""
    :Author: ampasmanusa (bancetzLaut) <0.ampasmanusa@gmail.com>
    :Created: 2023-01-04T22:52:13+07:00
    :Description: Stake.

    """
from typing import Final

_available_games: Final[set[str]] = {"Dice"}
