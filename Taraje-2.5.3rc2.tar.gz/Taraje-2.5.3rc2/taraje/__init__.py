# -*- coding: utf-8 -*-
"""
    :Author: ampasmanusa (bancetzLaut) <0.ampasmanusa@gmail.com>
    :Created: 2022-03-19T23:30:18+07:00
    :Updated: 2023-05-19T17:46:09+07:00
    :Version: 2.5.3rc2
    :Description: Taraje's Bot.

    """
