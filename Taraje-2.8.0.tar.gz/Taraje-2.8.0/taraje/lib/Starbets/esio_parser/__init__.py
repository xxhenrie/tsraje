# -*- coding: utf-8 -*-
"""
    :Author: ampasmanusa (bancetzLaut) <0.ampasmanusa@gmail.com>
    :Created: 2023-09-22T19:55:33+07:00
    :Updated: 2024-04-04T04:17:25+07:00
    :Version: 0.2.0
    :Description: Minimal Engine/Socket-IO Packet Parser (without binary attachments)

    """
